```python
#HOJA DE TRABAJO 1

##Marvin Diaz
##Carnet: 9516008
```


```python
conda install -c conda-forge opencv
```

    Collecting package metadata (current_repodata.json): ...working... done
    Note: you may need to restart the kernel to use updated packages.
    Solving environment: ...working... done
    
    # All requested packages already installed.
    
    
    


```python
pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\users\marvin\anaconda3\lib\site-packages (4.6.0.66)
    Requirement already satisfied: numpy>=1.19.3 in c:\users\marvin\anaconda3\lib\site-packages (from opencv-python) (1.20.3)
    Note: you may need to restart the kernel to use updated packages.
    

##Problema 1:
Desarrolle una funcion la cual reciba dos parametros, una imagen y un entero llamado color, la funcion debe devolver una imagen la cual tenga activos los canales de color segun los siguientes puntos:
Si el parametro color vale 1, la imagen debe mostrar activos unicamente el color azul.
Si el parametro color vale 2, la imagen debe mostrar activos unicamente el color verde.
Si el parametro color vale 3, la imagen debe mostrar activos unicamente el color rojo.
Si el parametro color vale 10, la imagen debe mostrar activos unicamente los colores rojo y verde.
Si el parametro color vale 20, la imagen debe mostrar activos unicamente los colores verde y azul.
Si el parametro color vale 30, la imagen debe mostrar activos unicamente los colores azul y rojo.



```python
import cv2
import matplotlib.pyplot as plt
import sys

import numpy as np
```


```python
img = cv2.imread("tree.jpg", cv2.IMREAD_COLOR)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x1e0a7692d60>




    
![png](output_5_1.png)
    



```python
alto = img.shape[0]
ancho = img.shape[1]
```


```python
lienzo = np.zeros((alto, ancho, 3))
```


```python
def canal_imagen(imagen, color):
    img = cv2.imread(imagen) #lectura en formato BGR
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    alto = img.shape[0]
    ancho =  img.shape[1]
    lienzo = np.zeros((alto,ancho,3)) #hace que la imagen de salida sea a color.
    for i in range(0, alto):
        for j in range(0, ancho):
            pixel = img[i,j]

            blue = pixel[2]
            green = pixel[1]
            red = pixel[0]
            
            if(color == 1):
                lienzo[i, j] = [blue, 0, 0]
            if(color == 2):
                lienzo[i, j] = [0, green, 0]
            if(color == 3):
                lienzo[i, j] = [0, 0, red]
            if(color == 10):
                lienzo[i, j] = [0, green, red]
            if(color == 20):
                lienzo[i, j] = [blue, green, 0]
            if(color == 30):
                lienzo[i, j] = [blue, 0, red]
                
    cv2.imwrite('monocromo.jpg', lienzo)
    monocromo = cv2.imread('monocromo.jpg')
    monocromo = cv2.cvtColor(monocromo, cv2.COLOR_BGR2RGB)
    return monocromo
```


```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 1))
plt.show()
```


    
![png](output_9_0.png)
    



```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 2))
plt.show()
```


    
![png](output_10_0.png)
    



```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 3))
plt.show()
```


    
![png](output_11_0.png)
    



```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 10))
plt.show()
```


    
![png](output_12_0.png)
    



```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 20))
plt.show()
```


    
![png](output_13_0.png)
    



```python
imagen_dir = 'tree.jpg'
plt.imshow(canal_imagen(imagen_dir, 30))
plt.show()
```


    
![png](output_14_0.png)
    


##Problema 2:
En el .zip del laboratorio se le compartio un conjunto de imágenes en escala de grises (imagen1, imagen2, perro) estas imagenes fueron creadas utilizando una escala de grises en 3D, cree una funcion que dadas las 3 imagenes se construya la imagen original a color


```python
def agregar_colores(imagenRD, imagenGR, imagenBL):
    imgRD = cv2.imread(imagenRD) #lectura en formato BGR
    imgRD = cv2.cvtColor(imgRD,cv2.COLOR_BGR2RGB)
    
    imgGR = cv2.imread(imagenGR) #lectura en formato BGR
    imgGR = cv2.cvtColor(imgGR,cv2.COLOR_BGR2RGB)
    
    imgBL = cv2.imread(imagenBL) #lectura en formato BGR
    imgBL = cv2.cvtColor(imgBL,cv2.COLOR_BGR2RGB)
    
    altoRD = imgRD.shape[0]
    anchoRD =  imgRD.shape[1]
    
    altoGR = imgGR.shape[0]
    anchoGR =  imgGR.shape[1]
    
    altoBL = imgBL.shape[0]
    anchoBL =  imgBL.shape[1]
    
    lienzo = np.zeros((altoRD,anchoRD,3)) #hace que la imagen de salida sea a color.
    for i in range(0, altoRD):
        for j in range(0, anchoRD):
            pixelR = imgRD[i,j]
            pixelG = imgGR[i,j]
            pixelB = imgBL[i,j]
            
            blueR = pixelR[2]
            greenR = pixelR[1]
            redR = pixelR[0]
            
            blueG = pixelG[2]
            greenG = pixelG[1]
            redG = pixelG[0]
            
            blueB = pixelB[2]
            greenB = pixelB[1]
            redB = pixelB[0]
            
            lienzo[i, j] = [blueB, greenG, redR]
            
                
    cv2.imwrite('imagen.jpg', lienzo)
    imagen = cv2.imread('imagen.jpg')
    imagen = cv2.cvtColor(imagen, cv2.COLOR_BGR2RGB)
    return imagen
```


```python
imagenBL_dir = 'imagen1/imagen1_salida_gray_azul.jpg'
imagenRD_dir = 'imagen1/imagen1_salida_gray_rojo.jpg'
imagenGR_dir = 'imagen1/imagen1_salida_gray_verde.jpg'
plt.imshow(agregar_colores(imagenRD_dir,imagenGR_dir,imagenBL_dir))
plt.show()
```


    
![png](output_17_0.png)
    



```python
imagen2BL_dir = 'imagen2/imagen2_salida_gray_azul.jpg'
imagen2RD_dir = 'imagen2/imagen2_salida_gray_rojo.jpg'
imagen2GR_dir = 'imagen2/imagen2_salida_gray_verde.jpg'
plt.imshow(agregar_colores(imagen2RD_dir,imagen2GR_dir,imagen2BL_dir))
plt.show()
```


    
![png](output_18_0.png)
    



```python
imagenBL_dir = 'perro/perro_salida_gray_azul.jpg'
imagenRD_dir = 'perro/perro_salida_gray_rojo.jpg'
imagenGR_dir = 'perro/perro_salida_gray_verde.jpg'
plt.imshow(agregar_colores(imagenRD_dir,imagenGR_dir,imagenBL_dir))
plt.show()
```


    
![png](output_19_0.png)
    


##Problema 3:
Cree una funcion que dada una imagen cree una escala de grises en tres dimensiones, tome en cuenta que su funcion debe crear 3 imagenes como salida. Para entregar este ejercicio debe incluir una las imagenes que haya utilizado como prueba y el resultado de las misma, no puede utilizar la imagen del Problema #2.


```python
img = cv2.imread("FIFA.jpg", cv2.IMREAD_COLOR)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x1e0a786e340>




    
![png](output_21_1.png)
    



```python
#dimensiones
alto = img.shape[0]
ancho = img.shape[1]
```


```python
media_ponderada = np.zeros((alto, ancho, 1)) #escala de grises
media_ponderada1= np.zeros((alto, ancho, 1))
media_ponderada2= np.zeros((alto, ancho, 1))
media_ponderada3= np.zeros((alto, ancho, 1))
```


```python
for i in range(0, alto):
    for j in range(0, ancho):
        pixel = img[i, j]
        
        blue = pixel[2]
        green = pixel[1]
        red = pixel[0]
        
        media_ponderada[i,j] = int(0.299*blue + 0.587*green + 0.114*red)
        media_ponderada1[i,j] = int(0.199*blue + 0.587*green + 0.214*red)
        media_ponderada2[i,j] = int(0.05*blue + 0.30*green + 0.65*red)
        media_ponderada3[i,j] = int(0.10*blue + 0.1*green + 0.80*red)
```


```python
media_ponderada
```




    array([[[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           ...,
    
           [[253.],
            [253.],
            [253.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[253.],
            [253.],
            [253.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[253.],
            [253.],
            [253.],
            ...,
            [253.],
            [253.],
            [253.]]])




```python
cv2.imwrite("gris_ponderado.jpg", media_ponderada)
gris = cv2.imread("gris_ponderado.jpg")
gris = cv2.cvtColor(gris, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(gris)
plt.show()
```


    
![png](output_27_0.png)
    



```python
media_ponderada3
```




    array([[[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           [[255.],
            [255.],
            [255.],
            ...,
            [253.],
            [253.],
            [253.]],
    
           ...,
    
           [[254.],
            [254.],
            [254.],
            ...,
            [254.],
            [254.],
            [254.]],
    
           [[254.],
            [254.],
            [254.],
            ...,
            [254.],
            [254.],
            [254.]],
    
           [[254.],
            [254.],
            [254.],
            ...,
            [254.],
            [254.],
            [254.]]])




```python
cv2.imwrite("gris_ponderado1.jpg", media_ponderada1)
gris1 = cv2.imread("gris_ponderado1.jpg")
gris1 = cv2.cvtColor(gris1, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(gris1)
plt.show()
```


    
![png](output_30_0.png)
    



```python
cv2.imwrite("gris_ponderado2.jpg", media_ponderada2)
gris2 = cv2.imread("gris_ponderado2.jpg")
gris2 = cv2.cvtColor(gris2, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(gris2)
plt.show()
```


    
![png](output_32_0.png)
    



```python
cv2.imwrite("gris_ponderado3.jpg", media_ponderada3)
gris3 = cv2.imread("gris_ponderado3.jpg")
gris3 = cv2.cvtColor(gris3, cv2.COLOR_BGR2RGB)
```


```python
plt.imshow(gris3)
plt.show()
```


    
![png](output_34_0.png)
    


##Problema 4:
Cree una función que dada una imagen, muestre el histograma de cada canal de color y el de escala de grises (utilice un promedio aritmetico para su escala de grises, no puede usar funciones de opencv), sus histogramas deben incluir una lınea vertical la cual muestre el valor de la media de la distribucion


```python
def EscalaGrises(img, nombre):
    alto = img.shape[0]
    ancho = img.shape[1]
    
    Salida = np.zeros(( alto,ancho, 3))
    
    for i in range(0,alto):
        for j in range(0, ancho):
            pixel = img[i,j]
            prom=int(np.mean(pixel))
            Salida[i,j]=[avg, avg, avg]
            
    cv2.imwrite(nombre+'escala.jpg', Salida)
    return Salida
    
```

##Problema 5:
Investigue en que consiste el enfoque de escala de grises ponderado, luego de esto implemente una funcion que dada una imagen, realice una escala de grises ponderada (notar que no existe una solucion unica).



```python
def gris_ponderado(imagen):
    img = cv2.imread(imagen) #lectura en formato BGR
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    alto = img.shape[0]
    ancho =  img.shape[1]
    gris_ponderado = np.zeros((alto,ancho,1))
    for i in range(0, alto):
        for j in range(0, ancho):
            pixel = img[i,j]

            blue = pixel[2]
            green = pixel[1]
            red = pixel[0]

            gris_ponderado[i,j] = int(0.299*blue + 0.587*green + 0.114*red)
    cv2.imwrite('gris_ponderado.jpg', gris_ponderado)
    gris_ponderado = cv2.imread('gris_ponderado.jpg')
    gris_ponderado = cv2.cvtColor(gris_ponderado, cv2.COLOR_BGR2RGB)
    return gris_ponderado
```


```python
imagen = 'tree.jpg'
plt.imshow(gris_ponderado(imagen))
plt.show()
```


    
![png](output_39_0.png)
    



```python

```

##Problema 6:
Investigue brevemente en que consiste el espacio de color HSV y como se mapean colores a dicho espacio, para entregar este ejercicio puede hacerlo por medio de Markdown en el mismo Notebook donde trabajo los demas ejercicios

El espacio de color HSV por sus siglas (hue, saturation and value), significa la combinacion de colores para representar el espectro que vemos.  A diferencia del RGB que es la forma mas popular de mezclar los colores, rojo, verde y azul. Los modelos RGB y CMYK usan los colores primarios, el HSV describe los colores (tono o tinte) en terminos de su tono (saturacion o cantidad de gris) y su valor de brillo.  

La rueda de color HSV es como un cilindro, siempre con los componentes de tinte, saturacion y valor (o brillo).


```python
img = cv2.imread("hsv.png", cv2.IMREAD_COLOR)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x1e0a7970130>




    
![png](output_43_1.png)
    

